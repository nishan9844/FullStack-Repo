<?php include "includes/header.php"; ?>

<p>Welcome to the Student Portfolio Manager </p>

<ul>
    <li><a href="public/add_student.php">Add Student Info</a></li>
    <li><a href="public/upload.php">Upload Portfolio File</a></li>
    <li><a href="public/students.php">View Students</a></li>
</ul>

<?php include "includes/footer.php"; ?>
