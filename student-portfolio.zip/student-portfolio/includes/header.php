<!DOCTYPE html>
<html>
<head>
    <title>Student Portfolio Manager</title>
    <link rel="stylesheet" href="/student-portfolio/assets/style.css">
</head>
<body>
<h2>Student Portfolio Manager</h2>
<hr>
