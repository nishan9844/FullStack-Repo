<?php
include "../includes/header.php";

$file = "../data/students.txt";

if (file_exists($file)) {
    $students = file($file);

    foreach ($students as $student) {
        list($name, $email, $skills) = explode("|", $student);
        echo "<p><b>$name</b> — $email</p>";
        echo "<p>Skills: $skills</p><hr>";
    }
} else {
    echo "<p>No students found.</p>";
}

include "../includes/footer.php";
