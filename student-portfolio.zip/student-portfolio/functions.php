<?php

function formatName($name) {
    return ucwords(trim($name));
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function cleanSkills($string) {
    return array_map("trim", explode(",", $string));
}

function saveStudent($name, $email, $skillsArray) {
    $file = __DIR__ . "/data/students.txt";
    $line = $name . "|" . $email . "|" . implode(",", $skillsArray) . PHP_EOL;
    file_put_contents($file, $line, FILE_APPEND);
}

function uploadPortfolioFile($file) {
    if ($file['error'] !== 0) {
        throw new Exception("Upload failed");
    }

    $allowed = ["pdf","jpg","jpeg","png"];
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($ext, $allowed)) {
        throw new Exception("Invalid file type");
    }

    if ($file['size'] > 2 * 1024 * 1024) {
        throw new Exception("File too large");
    }

    $target = __DIR__ . "/uploads/" . time() . "_" . basename($file['name']);
    move_uploaded_file($file['tmp_name'], $target);
}
